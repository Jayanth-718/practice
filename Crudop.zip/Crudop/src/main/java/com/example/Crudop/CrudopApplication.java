package com.example.Crudop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudopApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudopApplication.class, args);
	}

}
