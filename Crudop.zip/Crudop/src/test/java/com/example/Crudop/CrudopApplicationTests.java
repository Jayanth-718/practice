package com.example.Crudop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudopApplicationTests {

	@Test
	void contextLoads() {
	}

}
