package com.samp1.sampex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampexApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampexApplication.class, args);
	}

}
