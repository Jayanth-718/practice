package com.samp1.sampex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampexApplicationTests {

	@Test
	void contextLoads() {
	}

}
