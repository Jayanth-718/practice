package com.telsk.taskc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskcApplicationTests {

	@Test
	void contextLoads() {
	}

}
